<?php
/**
 * Crea y consulta pedidos; las compras se guardan en una transacción.
 */
class Eskaera extends Model
{
    /**
     * Recibe el carrito como producto => cantidad.
     * La transacción mantiene juntos el pedido, el stock y sus cuentas.
     */
    public function sortu(int $erabiltzaileId, array $saskia): int
    {
        $this->db->beginTransaction();
        try {
            $produktua = new Produktua();
            $inventarioDigital = new CuentaDigital();
            $guztira = 0.0;
            $lerroak = [];

            foreach ($saskia as $pid => $kop) {
                $p = $produktua->bilatu((int) $pid);
                if (!$p || $kop < 1) {
                    throw new RuntimeException('Produktu baliogabea saskian.');
                }
                $kontuIds = [];
                if (($p['kategoria'] ?? '') === 'Cuentas') {
                    $kontuIds = $inventarioDigital->bloquearDisponibles((int) $pid, (int) $kop);
                }
                if (!$produktua->stockMurriztu((int) $pid, (int) $kop)) {
                    throw new RuntimeException('Stock nahikorik ez: ' . $p['izena']);
                }
                $guztira += $p['prezioa'] * $kop;
                $lerroak[] = [$pid, $kop, $p['prezioa'], $kontuIds];
            }

            $this->execute(
                'INSERT INTO eskaerak (erabiltzailea_id, guztira, egoera) VALUES (?, ?, "berria")',
                [$erabiltzaileId, $guztira]
            );
            $eskaeraId = (int) $this->db->lastInsertId();

            foreach ($lerroak as [$pid, $kop, $prezioa, $kontuIds]) {
                $this->execute(
                    'INSERT INTO eskaera_lerroak (eskaera_id, produktua_id, kopurua, prezioa_unitarioa)
                     VALUES (?, ?, ?, ?)',
                    [$eskaeraId, $pid, $kop, $prezioa]
                );
                $lineaPedidoId = (int) $this->db->lastInsertId();
                $inventarioDigital->asignar($kontuIds, $lineaPedidoId);
            }

            $this->db->commit();
            return $eskaeraId;
        } catch (Throwable $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    /** Devuelve los pedidos de un usuario. */
    public function erabiltzailearenak(int $erabiltzaileId): array
    {
        return $this->fetchAll(
            'SELECT * FROM eskaerak WHERE erabiltzailea_id = ? ORDER BY data DESC',
            [$erabiltzaileId]
        );
    }

    /** Devuelve todos los pedidos con el nombre de cada cliente. */
    public function guztiak(): array
    {
        return $this->fetchAll(
            'SELECT e.*, u.izena AS bezeroa FROM eskaerak e
             JOIN erabiltzaileak u ON u.id = e.erabiltzailea_id ORDER BY e.data DESC'
        );
    }

    /** Busca un pedido por su identificador. */
    public function bilatu(int $id): ?array
    {
        return $this->fetchOne('SELECT * FROM eskaerak WHERE id = ?', [$id]);
    }

    /** Devuelve las líneas del pedido y sus cuentas entregadas. */
    public function lerroak(int $eskaeraId): array
    {
        $lerroak = $this->fetchAll(
            'SELECT l.*, p.izena, k.izena AS kategoria
             FROM eskaera_lerroak l
             JOIN produktuak p ON p.id = l.produktua_id
             LEFT JOIN kategoriak k ON k.id = p.kategoria_id
             WHERE l.eskaera_id = ?',
            [$eskaeraId]
        );

        $inventarioDigital = new CuentaDigital();
        foreach ($lerroak as &$lerroa) {
            $lerroa['cuentas'] = ($lerroa['kategoria'] ?? '') === 'Cuentas'
                ? $inventarioDigital->paraLinea((int) $lerroa['id'])
                : [];
        }
        unset($lerroa);

        return $lerroak;
    }

    /** Elimina un pedido y sus líneas en una sola transacción. */
    public function ezabatu(int $id): bool
    {
        $this->db->beginTransaction();
        try {
            $this->execute('DELETE FROM eskaera_lerroak WHERE eskaera_id = ?', [$id]);
            $ezabatuta = $this->execute('DELETE FROM eskaerak WHERE id = ?', [$id]) === 1;
            $this->db->commit();
            return $ezabatuta;
        } catch (Throwable $e) {
            $this->db->rollBack();
            throw $e;
        }
    }
}
